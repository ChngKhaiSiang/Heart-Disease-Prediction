import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
import streamlit as st

# Load your dataset
# Replace 'C:/Users/chngk/OneDrive/Desktop/Machine_learning/diabetes.csv' with the actual file path
data = pd.read_csv("C:/Users/chngk/OneDrive/Desktop/Machine_learning/heart_disease_health_indicators_BRFSS2015.csv")

# Combine prediabetes (1) into diabetes (2) in the 'Diabetes_binary' column
data['Diabetes'] = data['Diabetes'].replace({1: 2})

# Preprocessing
# Handle missing values
imputer = SimpleImputer(strategy='mean')
data[['BMI', 'HighBP', 'HighChol', 'CholCheck', 'Stroke', 'HeartDiseaseorAttack', 'PhysActivity', 
      'Fruits', 'Veggies', 'HvyAlcoholConsump', 'AnyHealthcare', 'NoDocbcCost', 'DiffWalk']] = imputer.fit_transform(data[[
      'BMI', 'HighBP', 'HighChol', 'CholCheck', 'Stroke', 'HeartDiseaseorAttack', 'PhysActivity', 
      'Fruits', 'Veggies', 'HvyAlcoholConsump', 'AnyHealthcare', 'NoDocbcCost', 'DiffWalk']])

# Feature scaling
scaler = StandardScaler()
data[['BMI', 'GenHlth', 'MentHlth', 'PhysHlth', 'DiffWalk', 'Age', 'Education', 'Income']] = scaler.fit_transform(data[[
    'BMI', 'GenHlth', 'MentHlth', 'PhysHlth', 'DiffWalk', 'Age', 'Education', 'Income']])

# Feature selection
features = ['HighBP', 'HighChol', 'CholCheck', 'BMI', 'Smoker', 'Stroke', 'HeartDiseaseorAttack',
            'PhysActivity', 'Fruits', 'Veggies', 'HvyAlcoholConsump', 'AnyHealthcare', 'NoDocbcCost',
            'GenHlth', 'MentHlth', 'PhysHlth', 'DiffWalk', 'Sex', 'Age', 'Education', 'Income']

X = data[features].copy()
y = data['Diabetes']

# Preprocess categorical features using OneHotEncoder
numeric_features = ['BMI', 'GenHlth', 'MentHlth', 'PhysHlth', 'DiffWalk', 'Age']

preprocessor = ColumnTransformer(
    transformers=[
        ('num', 'passthrough', numeric_features),
        # Add ('cat', YourCategoricalEncoder(), categorical_features) if needed
    ])

# Create a pipeline with preprocessing and RandomForest model
model = Pipeline(steps=[('preprocessor', preprocessor),
                         ('classifier', RandomForestClassifier())])

# Train the model
model.fit(X, y)

# Streamlit web app
st.title("Diabetes Prediction")

# User input for features
with st.form(key='my_form'):
    high_bp = st.radio("High Blood Pressure", options=["No", "Yes"])
    high_chol = st.radio("High Cholesterol", options=["No", "Yes"])
    chol_check = st.radio("Cholesterol Check in 5 Years", options=["No", "Yes"])
    bmi = st.number_input("Body Mass Index (BMI)", min_value=0)
    smoker = st.radio("Smoker", options=["No", "Yes"])
    stroke = st.radio("Ever had a Stroke", options=["No", "Yes"])
    heart_disease = st.radio("Coronary Heart Disease or Heart Attack", options=["No", "Yes"])
    phys_activity = st.radio("Physical Activity in Past 30 Days", options=["No", "Yes"])
    fruits = st.radio("Consume Fruits 1 or more times per day", options=["No", "Yes"])
    veggies = st.radio("Consume Vegetables 1 or more times per day", options=["No", "Yes"])
    alcohol_consump = st.radio("Heavy Alcohol Consumption", options=["No", "Yes"])
    healthcare = st.radio("Have any kind of Health Care Coverage", options=["No", "Yes"])
    no_doc_cost = st.radio("Couldn't see a Doctor in the past 12 months due to cost", options=["No", "Yes"])
    gen_hlth = st.number_input("General Health Rating (1 = Excellent, 5 = Poor)", min_value=1, max_value=5)
    ment_hlth = st.number_input("Days of Poor Mental Health (1-30 days)", min_value=0, max_value=30)
    phys_hlth = st.number_input("Physical Illness or Injury Days in Past 30 Days (1-30 days)", min_value=0, max_value=30)
    diff_walk = st.radio("Serious Difficulty Walking or Climbing Stairs", options=["No", "Yes"])
    sex = st.radio("Sex", options=["Female", "Male"])
    age_ranges = {
        1: '18 to 24', 2: '25 to 29', 3: '30 to 34', 4: '35 to 39', 5: '40 to 44',
        6: '45 to 49', 7: '50 to 54', 8: '55 to 59', 9: '60 to 64', 10: '65 to 69',
        11: '70 to 74', 12: '75 to 79', 13: '80 or older'
    }
    age = st.selectbox("Age", options=list(age_ranges.keys()), format_func=lambda x: age_ranges[x])
    education = st.selectbox("Education Level", [1, 2, 3, 4, 5, 6], format_func=lambda x: {
        1: 'Never Attended School or kindergarten',
        2: 'Grades 1 to 8',
        3: 'Grades 9 to 12',
        4: 'High School Graduate',
        5: 'Some College or Technical School',
        6: 'College Graduate'
    }[x])
    income = st.selectbox("Income Level", [1, 2, 3, 4, 5, 6, 7, 8], format_func=lambda x: {
        1: 'Less Than $10,000',
        2: 'Less Than $15,000',
        3: 'Less Than $20,000',
        4: 'Less Than $25,000',
        5: 'Less Than $35,000',
        6: 'Less Than $45,000',
        7: 'Less Than $65,000',
        8: '$75,000 or More'
    }[x])

    submitted = st.form_submit_button("Submit")

# Map radio button values to binary for relevant features
gender_mapping = {'Female': 0, 'Male': 1}
sex = gender_mapping[sex]

binary_mapping = {'No': 0, 'Yes': 1}  # Updated to use strings as keys
high_bp = binary_mapping[str(high_bp)]
high_chol = binary_mapping[str(high_chol)]
chol_check = binary_mapping[str(chol_check)]
smoker = binary_mapping[str(smoker)]
stroke = binary_mapping[str(stroke)]
heart_disease = binary_mapping[str(heart_disease)]
phys_activity = binary_mapping[str(phys_activity)]
fruits = binary_mapping[str(fruits)]
veggies = binary_mapping[str(veggies)]
alcohol_consump = binary_mapping[str(alcohol_consump)]
healthcare = binary_mapping[str(healthcare)]
no_doc_cost = binary_mapping[str(no_doc_cost)]
diff_walk = binary_mapping[str(diff_walk)]
# Create a button for submission
if submitted:
    
    # Create a DataFrame from user input
    user_data = pd.DataFrame({
        'HighBP': [high_bp],
        'HighChol': [high_chol],
        'CholCheck': [chol_check],
        'BMI': [bmi],
        'Smoker': [smoker],
        'Stroke': [stroke],
        'HeartDiseaseorAttack': [heart_disease],
        'PhysActivity': [phys_activity],
        'Fruits': [fruits],
        'Veggies': [veggies],
        'HvyAlcoholConsump': [alcohol_consump],
        'AnyHealthcare': [healthcare],
        'NoDocbcCost': [no_doc_cost],
        'GenHlth': [gen_hlth],
        'MentHlth': [ment_hlth],
        'PhysHlth': [phys_hlth],
        'DiffWalk': [diff_walk],
        'Sex': [sex],
        'Age': [age],
        'Education': [education],
        'Income': [income]
    })
    print("Input Data:")
    print(user_data)
    # Make prediction
    prediction = model.predict(user_data)
    print("Prediction Result:", prediction)
    # Display the prediction result
    if prediction[0] == 2:
        st.success("The model predicts that the person has diabetes.")
    else:
        st.success("The model predicts that the person does not have diabetes.")
