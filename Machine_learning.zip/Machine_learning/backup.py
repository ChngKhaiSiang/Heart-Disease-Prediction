import pandas as pd
from ydata_profiling import ProfileReport
import matplotlib.pyplot as plt 
import seaborn as sns 

# dataset report
data = pd.read_csv("C:/Users/chngk/OneDrive/Desktop/Machine_learning/heart_disease_health_indicators_BRFSS2015.csv", sep=",", encoding='utf-8')
# Create a profiling report
profile = ProfileReport(data)

# Save the report to an HTML file
profile.to_file("dataset_report.html")

# Print a message indicating the file location
print("Dataset report saved to dataset_report.html")

# preprocessing
data["HeartDiseaseorAttack"] = data["HeartDiseaseorAttack"].astype(int)
data["HighBP"] = data["HighBP"].astype(int)
data["HighChol"] = data["HighChol"].astype(int)
data["CholCheck"] = data["CholCheck"].astype(int)
data["BMI"] = data["BMI"].astype(int)
data["Smoker"] = data["Smoker"].astype(int)
data["Stroke"] = data["Stroke"].astype(int)
data["Diabetes"] = data["Diabetes"].astype(int)
data["PhysActivity"] = data["PhysActivity"].astype(int)
data["Fruits"] = data["Fruits"].astype(int) 
data["Veggies"] = data["Veggies"].astype(int)
data["HvyAlcoholConsump"] = data["HvyAlcoholConsump"].astype(int)
data["AnyHealthcare"] = data["AnyHealthcare"].astype(int)
data["NoDocbcCost"] = data["NoDocbcCost"].astype(int)
data["GenHlth"] = data["GenHlth"].astype(int)
data["MentHlth"] = data["MentHlth"].astype(int)
data["PhysHlth"] = data["PhysHlth"].astype(int)
data["DiffWalk"] = data["DiffWalk"].astype(int)
data["Sex"] = data["Sex"].astype(int)
data["Age"] = data["Age"].astype(int)
data["Education"] = data["Education"].astype(int)
data["Income"] = data["Income"].astype(int)
data.info()

# check null value
print(data.isnull().values.any())
print(data.isnull().sum())
data.dropna(inplace=True)

# checking unique values in different variables
unique_values = {}
for col in data.columns:
    unique_values[col] = data[col].value_counts().shape[0]

print(pd.DataFrame(unique_values, index=['unique value count']).transpose())

# check duplicated data
print(data.duplicated().sum())
# drop duplicated data
data.drop_duplicates(inplace=True)

data["Diabetes_str"] = data["Diabetes"].replace({0: "Not_Diabetic", 1: "Prediabetic", 2:"Diabetic"})

# Heatmap correlation------------------------------------------------------------------------
numeric_data = data.select_dtypes(include=['int', 'float'])
plt.figure(figsize=(20, 15))
sns.heatmap(numeric_data.corr(), annot=True, fmt=".2f")
plt.title("Features Correlation")
plt.show()

#histogram to understand dataset------------------------------------------------------------
data.hist(figsize=(20,15));

testdata=data.copy() 

testdata.Diabetes[testdata['Diabetes'] == 0] = 'No Diabetes'
testdata.Diabetes[testdata['Diabetes'] == 1] = 'Prediabetes'
testdata.Diabetes[testdata['Diabetes'] == 2] = 'Diabetes'


testdata.HighBP[testdata['HighBP'] == 0] = 'No High BP'
testdata.HighBP[testdata['HighBP'] == 1] = 'High BP'

testdata.HighChol[testdata['HighChol'] == 0] = 'No High Cholesterol'
testdata.HighChol[testdata['HighChol'] == 1] = 'High Cholesterol'

testdata.CholCheck[testdata['CholCheck'] == 0] = 'No Cholesterol Check in 5 Years'
testdata.CholCheck[testdata['CholCheck'] == 1] = 'Cholesterol Check in 5 Years'

testdata.Smoker[testdata['Smoker'] == 0] = 'No'
testdata.Smoker[testdata['Smoker'] == 1] = 'Yes'

testdata.Stroke[testdata['Stroke'] == 0] = 'No'
testdata.Stroke[testdata['Stroke'] == 1] = 'Yes'

testdata.HeartDiseaseorAttack[testdata['HeartDiseaseorAttack'] == 0] = 'No'
testdata.HeartDiseaseorAttack[testdata['HeartDiseaseorAttack'] == 1] = 'Yes'

testdata.PhysActivity[testdata['PhysActivity'] == 0] = 'No'
testdata.PhysActivity[testdata['PhysActivity'] == 1] = 'Yes'

testdata.Fruits[testdata['Fruits'] == 0] = 'No'
testdata.Fruits[testdata['Fruits'] == 1] = 'Yes'

testdata.Veggies[testdata['Veggies'] == 0] = 'No'
testdata.Veggies[testdata['Veggies'] == 1] = 'Yes'

testdata.HvyAlcoholConsump[testdata['HvyAlcoholConsump'] == 0] = 'No'
testdata.HvyAlcoholConsump[testdata['HvyAlcoholConsump'] == 1] = 'Yes'

testdata.AnyHealthcare[testdata['AnyHealthcare'] == 0] = 'No'
testdata.AnyHealthcare[testdata['AnyHealthcare'] == 1] = 'Yes'

testdata.NoDocbcCost[testdata['NoDocbcCost'] == 0] = 'No'
testdata.NoDocbcCost[testdata['NoDocbcCost'] == 1] = 'Yes'

testdata.GenHlth[testdata['GenHlth'] == 5] = 'Excellent'
testdata.GenHlth[testdata['GenHlth'] == 4] = 'Very Good'
testdata.GenHlth[testdata['GenHlth'] == 3] = 'Good'
testdata.GenHlth[testdata['GenHlth'] == 2] = 'Fair'
testdata.GenHlth[testdata['GenHlth'] == 1] = 'Poor'

testdata.DiffWalk[testdata['DiffWalk'] == 0] = 'No'
testdata.DiffWalk[testdata['DiffWalk'] == 1] = 'Yes'

testdata.Sex[testdata['Sex'] == 0] = 'Female'
testdata.Sex[testdata['Sex'] == 1] = 'Male'

testdata.Age[testdata['Age'] == 1] = '18 to 24'
testdata.Age[testdata['Age'] == 2] = '25 to 29'
testdata.Age[testdata['Age'] == 3] = '30 to 34'
testdata.Age[testdata['Age'] == 4] = '35 to 39'
testdata.Age[testdata['Age'] == 5] = '40 to 44'
testdata.Age[testdata['Age'] == 6] = '45 to 49'
testdata.Age[testdata['Age'] == 7] = '50 to 54'
testdata.Age[testdata['Age'] == 8] = '55 to 59'
testdata.Age[testdata['Age'] == 9] = '60 to 64'
testdata.Age[testdata['Age'] == 10] = '65 to 69'
testdata.Age[testdata['Age'] == 11] = '70 to 74'
testdata.Age[testdata['Age'] == 12] = '75 to 79'
testdata.Age[testdata['Age'] == 13] = '80 or older'

testdata.Education[testdata['Education'] == 1] = 'Never Attended School or kindergarten'
testdata.Education[testdata['Education'] == 2] = 'Grades 1 to 8'
testdata.Education[testdata['Education'] == 3] = 'Grades 9 to 12'
testdata.Education[testdata['Education'] == 4] = 'High School Graduate'
testdata.Education[testdata['Education'] == 5] = 'Some College or Technical School'
testdata.Education[testdata['Education'] == 6] = 'College Graduate'

testdata.Income[testdata['Income'] == 1] = 'Less Than $10,000'
testdata.Income[testdata['Income'] == 2] = 'Less Than $15,000'
testdata.Income[testdata['Income'] == 3] = 'Less Than $20,000'
testdata.Income[testdata['Income'] == 4] = 'Less Than $25,000'
testdata.Income[testdata['Income'] == 5] = 'Less Than $35,000'
testdata.Income[testdata['Income'] == 6] = 'Less Than $45,000'
testdata.Income[testdata['Income'] == 7] = 'Less Than $65,000'
testdata.Income[testdata['Income'] == 8] = '$75,000 or More'


# [Yes - NO] Columns and their relation with diabetes----------------------------------------
cols = ['HighBP', 'HighChol', 'CholCheck', 'Smoker', 'Stroke', 'HeartDiseaseorAttack',
        'PhysActivity', 'Fruits', 'Veggies', 'HvyAlcoholConsump', 'AnyHealthcare', 'NoDocbcCost',
        'DiffWalk']

def create_pivot(testdata, x_column):
    """Create a pivot table for satisfaction versus another rating for easy plotting."""
    df_plot = testdata.groupby([x_column, 'Diabetes_str']).size() \
        .reset_index().pivot(columns='Diabetes_str', index=x_column, values=0)
    return df_plot

# Set the color palette to "tab10"
sns.set_palette("tab10")
# Create subplots for [Yes - NO] Columns and their relation with diabetes
fig, axes = plt.subplots(5, 3, figsize=(20, 20))
axes = axes.ravel()
for i, col in enumerate(cols):
    create_pivot(testdata, col).plot(kind='bar', stacked=True, ax=axes[i])
    axes[i].set_xlabel(col)
    
# Adjust the space between subplots
plt.subplots_adjust(hspace=0.5, wspace=0.5)
# Set the title for the entire figure
fig.suptitle('[Yes - NO] Columns and their relation with Diabetes', fontsize=15)
plt.show()

# Pie chart for checking diabetic and non-diabetic people average----------------------------
fig, ax = plt.subplots(figsize=(8, 8))

# Create the pie chart using the entire dataset
labels = ["Not_Diabetic", "Diabetic", "Prediabetic"]
ax.pie(testdata["Diabetes_str"].value_counts(), labels=labels, autopct='%.02f')
ax.set_title('Distribution of Diabetes in the Dataset')
plt.show()

# Create a bar plot for Diabetes Disease Frequency for Ages----------------------------------
sns.set(style="whitegrid")
plt.figure(figsize=(12, 8))
# Define the order of age groups
age_order = [
    '18 to 24', '25 to 29', '30 to 34', '35 to 39', '40 to 44',
    '45 to 49', '50 to 54', '55 to 59', '60 to 64', '65 to 69',
    '70 to 74', '75 to 79', '80 or older'
]
# Use the order parameter to set the order of the x-axis (Age)
sns.countplot(x="Age", hue="Diabetes_str", data=testdata, palette="rocket", order=age_order)
# Set the title and labels
plt.title("Diabetes Disease Frequency for Ages", fontsize=18)
plt.xlabel("Age Group", fontsize=14)
plt.ylabel("Frequency", fontsize=14)
# Show the legend
plt.legend(title="Diabetes", loc="upper right", labels=["Not Diabetic", "Diabetic", "Prediabetic"])
# Rotate x-axis labels for better readability
plt.xticks(rotation=45)
plt.show()

#Relation between Sex and Diabetes--------------------------------------------------------
sns.countplot(x='Sex', hue='Diabetes_str', data=testdata)
sns.set_palette("Spectral")
plt.title('Relation between Gender and Diabetes')
plt.xlabel('Gender')
plt.ylabel('Count')
plt.show()

#BMI Distribution by Diabetes Status------------------------------------------------------
# Map numerical values to labels in the "Diabetes_str" column
data['Diabetes_str'] = data['Diabetes'].map({0: 'No Diabetes', 1: 'Prediabetes', 2: 'Diabetes'})

# Create a bar plot for "BMI" and its relation with "Diabetes"
plt.figure(figsize=(25, 15))
sns.countplot(data=data, x='BMI', hue='Diabetes_str', palette={"No Diabetes": "red", "Prediabetes": "green", "Diabetes": "blue"})
plt.title("Relation between BMI and Diabetes status")
plt.legend(title='Diabetes Status')
plt.show()

# Create a hist plot for Relation between Education and Diabetes-----------------------------
education_order = [
    'Never Attended School or kindergarten',
    'Grades 1 to 8',
    'Grades 9 to 12',
    'High School Graduate',
    'Some College or Technical School',
    'College Graduate'
]

testdata['Education'] = pd.Categorical(testdata['Education'], categories=education_order, ordered=True)

# Plot the distribution
plt.figure(figsize=(16, 8))
ax = sns.histplot(data=testdata[testdata["Diabetes_str"] == 'Not_Diabetic'], x='Education', color="tomato", label="Not_Diabetic", binwidth=0.5, stat="count")
sns.histplot(data=testdata[testdata["Diabetes_str"] == 'Prediabetic'], x='Education', color="gold", label="Prediabetic", binwidth=0.5, stat="count", ax=ax)
sns.histplot(data=testdata[testdata["Diabetes_str"] == 'Diabetic'], x='Education', color="mediumseagreen", label="Diabetic", binwidth=0.5, stat="count", ax=ax)

ax.set_title("Relation between Education and Diabetes")
ax.set_xlabel("Education Level")
ax.set_ylabel("Count")

# Set x-axis tick positions and labels
tick_positions = range(len(education_order))
ax.set_xticks(tick_positions)
ax.set_xticklabels(education_order, rotation=45)

# Create a twin Axes sharing the xaxis
ax2 = ax.twinx()

# Plot the KDE on the second y-axis with labels
sns.histplot(data=testdata[testdata["Diabetes_str"] == 'Not_Diabetic'], x='Education', color="tomato", label="Not_Diabetic", binwidth=0.5, stat="density", kde=True, ax=ax2)
sns.histplot(data=testdata[testdata["Diabetes_str"] == 'Prediabetic'], x='Education', color="gold", label="Prediabetic", binwidth=0.5, stat="density", kde=True, ax=ax2)
sns.histplot(data=testdata[testdata["Diabetes_str"] == 'Diabetic'], x='Education', color="mediumseagreen", label="Diabetic", binwidth=0.5, stat="density", kde=True, ax=ax2)

ax2.set_ylabel("Density")

# Show the legend
handles, labels = ax.get_legend_handles_labels()
handles2, labels2 = ax2.get_legend_handles_labels()
ax.legend(handles=handles + handles2, labels=labels + labels2, title="Diabetes", loc="upper right")

# Show the plot
plt.tight_layout()
plt.show()

# Define the order of "Income" categories----------------------------------------------------
income_order = [
    'Less Than $10,000',
    'Less Than $15,000',
    'Less Than $20,000',
    'Less Than $25,000',
    'Less Than $35,000',
    'Less Than $45,000',
    'Less Than $65,000',
    '$75,000 or More'
]
# Convert 'Income' to categorical with the specified order
testdata['Income'] = pd.Categorical(testdata['Income'], categories=income_order, ordered=True)

# Set the style of seaborn
sns.set(style="whitegrid")

# Create a distribution plot for "Income" and its relation with "Diabetes"
plt.figure(figsize=(14, 8))
sns.histplot(data=testdata, x="Income", hue="Diabetes_str", multiple="stack", palette="viridis", kde=True)
plt.title('Distribution of Income and its relation with Diabetes')
plt.xlabel('Income')
plt.ylabel('Count')
plt.show()


# Dist plot for "GenHlth" and its relation with the target
plt.figure(figsize=(12, 8))
sns.histplot(data=testdata, x="GenHlth", hue="Diabetes_str", multiple="stack", bins=5, palette="rocket")
plt.title('Distribution of General Health and its Relation with Diabetes')
plt.xlabel('General Health Rating (1 = Excellent, 5 = Poor)')
plt.ylabel('Count')
plt.show()


# Assuming your target variable is named "Diabetes_str"
sns.set(style="whitegrid")
plt.figure(figsize=(12, 6))
# Distribution plot for "MentHlth"
sns.distplot(testdata[testdata['Diabetes_str'] == 'Not_Diabetic']['MentHlth'], label='Not Diabetic', hist=False, kde_kws={'shade': True})
sns.distplot(testdata[testdata['Diabetes_str'] == 'Diabetic']['MentHlth'], label='Diabetic', hist=False, kde_kws={'shade': True})
sns.distplot(testdata[testdata['Diabetes_str'] == 'Prediabetic']['MentHlth'], label='Prediabetic', hist=False, kde_kws={'shade': True})
plt.title('Distribution of "MentHlth" and its Relation with Diabetes')
plt.xlabel('Days of Poor Mental Health (MentHlth)')
plt.legend()
plt.show()

sns.set(style="whitegrid")
plt.figure(figsize=(12, 8))
# Dist plot for PhysHlth based on the target variable
ax = sns.histplot(data=testdata, x='PhysHlth', hue='Diabetes_str', multiple="stack", bins=30, kde=True)
plt.title('Distribution of PhysHlth and its Relation with Diabetes')
plt.xlabel('PhysHlth (Physical illness or injury days in the past 30 days)')
plt.ylabel('Count')
# Manually create legend with specified colors
legend_labels = ['Not_Diabetic', 'Diabetic', 'Prediabetic']
legend_colors = sns.color_palette()[:len(legend_labels)]
legend_handles = [plt.Line2D([0], [0], color=legend_colors[i], label=legend_labels[i]) for i in range(len(legend_labels))]
plt.legend(handles=legend_handles, title='Diabetes', loc='upper right')
plt.show()

import pandas as pd
from sklearn.model_selection import train_test_split, RandomizedSearchCV
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import mean_squared_error, classification_report, confusion_matrix
import math
import matplotlib.pyplot as plt
from sklearn.metrics import ConfusionMatrixDisplay

# Combine prediabetic and diabetic to high-risk diabetic
testdata['Diabetes'] = testdata['Diabetes'].replace({0: 'No Diabetes', 1: 'Prediabetes', 2: 'Diabetes'})

# Map string values to numerical values
testdata['Diabetes'] = testdata['Diabetes'].map({'No Diabetes': 0, 'Prediabetes': 1, 'Diabetes': 1})

# Assuming 'HighBP' is a categorical variable, replace it with the actual name of the categorical variable
categorical_columns = ['HighBP', 'HighChol', 'CholCheck', 'BMI', 'Smoker', 'Stroke', 'HeartDiseaseorAttack', 'PhysActivity', 'Fruits', 'Veggies', 'HvyAlcoholConsump', 'AnyHealthcare', 'NoDocbcCost', 'GenHlth', 'MentHlth', 'PhysHlth', 'DiffWalk', 'Sex', 'Age', 'Education', 'Income']

# One-hot encode categorical variables
X_encoded = pd.get_dummies(testdata[['HighBP', 'HighChol', 'CholCheck', 'BMI', 'Smoker', 'Stroke', 'HeartDiseaseorAttack', 'PhysActivity', 'Fruits', 'Veggies', 'HvyAlcoholConsump', 'AnyHealthcare', 'NoDocbcCost', 'GenHlth', 'MentHlth', 'PhysHlth', 'DiffWalk', 'Sex', 'Age', 'Education', 'Income']], columns=categorical_columns)

# Combine prediabetic and diabetic to high-risk diabetic
y = testdata['Diabetes']

# Reduce the training set size for faster training
X_train, X_test, Y_train, Y_test = train_test_split(X_encoded, y, test_size=0.2, random_state=42, train_size=0.2)

# Hyperparameter tuning using random search with reduced search space and parallelization
param_distributions = {'C': [0.001, 0.01, 0.1, 1, 10, 100, 1000], 'penalty': ['l2']}  # Include only 'l2' for lbfgs solver
lg = LogisticRegression(max_iter=1500, solver='lbfgs')  # Explicitly set the solver
random_search = RandomizedSearchCV(lg, param_distributions, n_iter=5, scoring='accuracy', cv=5, random_state=42, n_jobs=-1)
random_search.fit(X_train, Y_train)

# Get the best hyperparameters
best_params = random_search.best_params_
print("Best Hyperparameters:", best_params)

# Initialize and fit the logistic regression model with the best hyperparameters
lg = LogisticRegression(max_iter=1500, C=best_params['C'], penalty=best_params['penalty'], solver='lbfgs')
lg.fit(X_train, Y_train)

# Make predictions on the test set
y_pred = lg.predict(X_test)

# Print training and test set scores
print('Training set score: {:.4f}'.format(lg.score(X_train, Y_train)))
print('Test set score: {:.4f}'.format(lg.score(X_test, Y_test)))

# Check MSE & RMSE
mse = mean_squared_error(Y_test, y_pred)
print('Mean Squared Error: {:.4f}'.format(mse))
rmse = math.sqrt(mse)
print('Root Mean Squared Error: {:.4f}'.format(rmse))

# Display classification report
matrix = classification_report(Y_test, y_pred)
print(matrix)

# Calculate and plot the confusion matrix
cm = confusion_matrix(Y_test, y_pred)
disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=['No Diabetes', 'Diabetes'])
disp.plot(cmap='Blues', values_format='.2f', colorbar=True)

plt.show()

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split, RandomizedSearchCV
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix, roc_curve, auc, mean_squared_error
import matplotlib.pyplot as plt
from sklearn.metrics import ConfusionMatrixDisplay

# Assuming 'HighBP' is a categorical variable, replace it with the actual name of the categorical variable
categorical_columns = ['HighBP', 'HighChol', 'CholCheck', 'BMI', 'Smoker', 'Stroke', 'HeartDiseaseorAttack', 'PhysActivity', 'Fruits', 'Veggies', 'HvyAlcoholConsump', 'AnyHealthcare', 'NoDocbcCost', 'GenHlth', 'MentHlth', 'PhysHlth', 'DiffWalk', 'Sex', 'Age', 'Education', 'Income']

# Combine prediabetic and diabetic to high-risk diabetic
y = testdata['Diabetes']

# One-hot encode categorical variables
X_encoded = pd.get_dummies(testdata[categorical_columns], columns=categorical_columns)

# Reduce the training set size for faster training
X_train, X_test, Y_train, Y_test = train_test_split(X_encoded, y, test_size=0.2, train_size=0.2, random_state=42)

# Hyperparameter tuning using random search with reduced iterations
param_distributions = {
    'n_estimators': [50, 100],
    'max_depth': [None, 10, 20],
    'min_samples_split': [2, 5],
    'min_samples_leaf': [1, 2]
}

rf = RandomForestClassifier(random_state=42)
random_search = RandomizedSearchCV(rf, param_distributions, n_iter=5, scoring='accuracy', cv=5, random_state=42)
random_search.fit(X_train, Y_train)

# Get the best hyperparameters
best_params = random_search.best_params_
print("Best Hyperparameters:", best_params)

# Initialize and fit the Random Forest model with the best hyperparameters and reduced trees
rf = RandomForestClassifier(
    n_estimators=best_params['n_estimators'],
    max_depth=best_params['max_depth'],
    min_samples_split=best_params['min_samples_split'],
    min_samples_leaf=best_params['min_samples_leaf'],
    random_state=42
)
rf.fit(X_train, Y_train)

# Make predictions on the test set
y_pred = rf.predict(X_test)

# Print training and test set scores
print('Training set score: {:.4f}'.format(rf.score(X_train, Y_train)))
print('Test set score: {:.4f}'.format(rf.score(X_test, Y_test)))

# Calculate Mean Squared Error (MSE)
mse = mean_squared_error(Y_test, y_pred)
print('Mean Squared Error: {:.4f}'.format(mse))
# Calculate Root Mean Squared Error (RMSE)
rmse = np.sqrt(mse)
print('Root Mean Squared Error: {:.4f}'.format(rmse))

# Display classification report
matrix = classification_report(Y_test, y_pred)
print(matrix)

# Calculate and plot the confusion matrix
cm = confusion_matrix(Y_test, y_pred)
disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=['No Diabetes', 'Diabetes'])
disp.plot(cmap='Purples', values_format='.2f', colorbar=True)
plt.show()

# Calculate ROC curve and AUC
y_pred_proba = rf.predict_proba(X_test)[:, 1]
fpr, tpr, thresholds = roc_curve(Y_test, y_pred_proba)
roc_auc = auc(fpr, tpr)

# Plot ROC curve
plt.figure(figsize=(8, 8))
plt.plot(fpr, tpr, color='darkorange', lw=2, label='ROC curve (AUC = {:.2f})'.format(roc_auc))
plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('Receiver Operating Characteristic (ROC) Curve')
plt.legend(loc='lower right')
plt.show()

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split, RandomizedSearchCV
from xgboost import XGBClassifier
from sklearn.metrics import classification_report, confusion_matrix, roc_curve, auc
import matplotlib.pyplot as plt
from sklearn.metrics import ConfusionMatrixDisplay

# Load the data
data = pd.read_csv("C:/Users/chngk/OneDrive/Desktop/Machine_learning/heart_disease_health_indicators_BRFSS2015.csv", sep=",", encoding='utf-8')

# Assuming 'HighBP' is a categorical variable, replace it with the actual name of the categorical variable
categorical_columns = ['HighBP', 'HighChol', 'CholCheck', 'BMI', 'Smoker', 'Stroke', 'HeartDiseaseorAttack', 'PhysActivity', 'Fruits', 'Veggies', 'HvyAlcoholConsump', 'AnyHealthcare', 'NoDocbcCost', 'GenHlth', 'MentHlth', 'PhysHlth', 'DiffWalk', 'Sex', 'Age', 'Education', 'Income']

# Combine prediabetic and diabetic to high-risk diabetic
data['Diabetes'] = data['Diabetes'].replace({0: 0, 1: 1, 2: 1})

# One-hot encode categorical variables
X_encoded = pd.get_dummies(data[categorical_columns], columns=categorical_columns)

# Split the data into training and testing sets
X_train, X_test, Y_train, Y_test = train_test_split(X_encoded, data['Diabetes'], test_size=0.2, train_size=0.2, random_state=42)

# Define the parameter grid for random search
param_dist = {
    'n_estimators': [50, 100, 150],
    'max_depth': [3, 5, 7],
    'learning_rate': [0.01, 0.1, 0.2]
}

# Initialize the XGBoost model
xgb = XGBClassifier(random_state=42)

# Initialize RandomizedSearchCV
random_search = RandomizedSearchCV(estimator=xgb, param_distributions=param_dist, n_iter=10, scoring='accuracy', cv=5, random_state=42)

# Fit RandomizedSearchCV on training data
random_search.fit(X_train, Y_train)

# Get the best parameters
best_params = random_search.best_params_

# Print the best parameters
print("Best Hyperparameters:", best_params)

# Use the best parameters to initialize the final model
xgb_best = XGBClassifier(random_state=42, **best_params)
xgb_best.fit(X_train, Y_train)

# Make predictions on the test set
y_pred = xgb_best.predict(X_test)

# Print training and test set scores
print('Training set score: {:.4f}'.format(xgb_best.score(X_train, Y_train)))
print('Test set score: {:.4f}'.format(xgb_best.score(X_test, Y_test)))

# Calculate Mean Squared Error (MSE)
mse = mean_squared_error(Y_test, y_pred)
print('Mean Squared Error: {:.4f}'.format(mse))
# Calculate Root Mean Squared Error (RMSE)
rmse = np.sqrt(mse)
print('Root Mean Squared Error: {:.4f}'.format(rmse))

# Display classification report
matrix = classification_report(Y_test, y_pred)
print(matrix)

# Calculate and plot the confusion matrix
cm = confusion_matrix(Y_test, y_pred)
disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=['No Diabetes', 'High-Risk Diabetic'])
disp.plot(cmap='Reds', values_format='.2f', colorbar=True)
plt.show()

# Convert categorical labels to binary (0 and 1)
Y_test_binary = Y_test.replace({'No Diabetes': 0, 'High-Risk Diabetic': 1})

# Calculate ROC curve and AUC
y_pred_proba = xgb_best.predict_proba(X_test)[:, 1]
fpr, tpr, thresholds = roc_curve(Y_test_binary, y_pred_proba)
roc_auc = auc(fpr, tpr)

# Plot ROC curve
plt.figure(figsize=(8, 8))
plt.plot(fpr, tpr, color='darkorange', lw=2, label='ROC curve (AUC = {:.2f})'.format(roc_auc))
plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('Receiver Operating Characteristic (ROC) Curve')
plt.legend(loc='lower right')
plt.show()

import matplotlib.pyplot as plt
import numpy as np
from sklearn.model_selection import train_test_split

# Set a fixed number of samples (e.g., 20,000)
num_samples = 20000

# Sample a subset of your data
X_subset = X_encoded.sample(n=num_samples, random_state=42)

# Reset indices for both X_subset and y
X_subset.reset_index(drop=True, inplace=True)
y.reset_index(drop=True, inplace=True)

y_subset = y[X_subset.index]

# Use the same split for training and testing sets
X_train, X_test, Y_train, Y_test = train_test_split(X_subset, y_subset, test_size=0.2, random_state=42)

# One-hot encode categorical variables in the testing set using the columns from training
X_encoded_test = pd.get_dummies(testdata[categorical_columns], columns=categorical_columns)

# Reindex X_encoded_test to have the same columns as X_train
X_encoded_test = X_encoded_test.reindex(columns=X_train.columns, fill_value=0)

# Align the indices of X_encoded_test and Y_test
X_encoded_test, Y_test = X_encoded_test.align(Y_test.to_frame(), axis=0, join='inner')

# Provide feature names to avoid the warning
feature_names = X_encoded_test.columns.tolist()

# Assign feature names to X_encoded_test
X_encoded_test.columns = feature_names

# Accuracy scores for each model
accuracy_scores = [
    lg.score(X_encoded_test.values, Y_test),
    rf.score(X_encoded_test.values, Y_test),
    xgb_best.score(X_encoded_test.values, Y_test)
]

# Mean Squared Error for each model
mse_scores = [
    mean_squared_error(Y_test, lg.predict(X_encoded_test.values)),
    mean_squared_error(Y_test, rf.predict(X_encoded_test.values)),
    mean_squared_error(Y_test, xgb_best.predict(X_encoded_test.values))
]

# Root Mean Squared Error for each model
rmse_scores = [np.sqrt(mse) for mse in mse_scores]

# Model names
models = ['Logistic Regression', 'Random Forest', 'XGBoost']

# Debugging Print Statements
print('Unique values in Y_test:', Y_test.unique())

for model, acc, mse, rmse in zip(models, accuracy_scores, mse_scores, rmse_scores):
    print(f'{model}:')
    print(f'  Accuracy: {acc:.4f}')
    print(f'  Mean Squared Error: {mse:.4f}')
    print(f'  Root Mean Squared Error: {rmse:.4f}')
    print()

    # Additional Debugging Print Statements
    print(f'  Unique Predictions for {model}: {np.unique(lg.predict(X_encoded_test.values))}')
    print(f'  Unique Predictions for {model}: {np.unique(rf.predict(X_encoded_test.values))}')
    print(f'  Unique Predictions for {model}: {np.unique(xgb_best.predict(X_encoded_test.values))}')
    print()

# Plotting
fig, ax1 = plt.subplots(figsize=(10, 6))

color = 'tab:red'
ax1.set_xlabel('Models')
ax1.set_ylabel('Accuracy', color=color)
ax1.bar(models, accuracy_scores, color=color)
ax1.tick_params(axis='y', labelcolor=color)

ax2 = ax1.twinx()
color = 'tab:blue'
ax2.set_ylabel('RMSE', color=color)
ax2.plot(models, rmse_scores, color=color, marker='o')
ax2.tick_params(axis='y', labelcolor=color)

fig.tight_layout()
plt.title('Model Comparison (Accuracy and RMSE)')
plt.show()



