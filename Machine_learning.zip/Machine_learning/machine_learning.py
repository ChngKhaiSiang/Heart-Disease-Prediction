import pandas as pd
from ydata_profiling import ProfileReport
import matplotlib.pyplot as plt 
import seaborn as sns 

# dataset report
data = pd.read_csv("C:/Users/chngk/OneDrive/Desktop/Machine_learning/heart_disease_health_indicators_BRFSS2015.csv", sep=",", encoding='utf-8')
# Create a profiling report
profile = ProfileReport(data)

# Save the report to an HTML file
profile.to_file("dataset_report.html")

# Print a message indicating the file location
print("Dataset report saved to dataset_report.html")

# preprocessing
data["HeartDiseaseorAttack"] = data["HeartDiseaseorAttack"].astype(int)
data["HighBP"] = data["HighBP"].astype(int)
data["HighChol"] = data["HighChol"].astype(int)
data["CholCheck"] = data["CholCheck"].astype(int)
data["BMI"] = data["BMI"].astype(int)
data["Smoker"] = data["Smoker"].astype(int)
data["Stroke"] = data["Stroke"].astype(int)
data["Diabetes"] = data["Diabetes"].astype(int)
data["PhysActivity"] = data["PhysActivity"].astype(int)
data["Fruits"] = data["Fruits"].astype(int) 
data["Veggies"] = data["Veggies"].astype(int)
data["HvyAlcoholConsump"] = data["HvyAlcoholConsump"].astype(int)
data["AnyHealthcare"] = data["AnyHealthcare"].astype(int)
data["NoDocbcCost"] = data["NoDocbcCost"].astype(int)
data["GenHlth"] = data["GenHlth"].astype(int)
data["MentHlth"] = data["MentHlth"].astype(int)
data["PhysHlth"] = data["PhysHlth"].astype(int)
data["DiffWalk"] = data["DiffWalk"].astype(int)
data["Sex"] = data["Sex"].astype(int)
data["Age"] = data["Age"].astype(int)
data["Education"] = data["Education"].astype(int)
data["Income"] = data["Income"].astype(int)
data.info()

# check null value
print(data.isnull().values.any())
print(data.isnull().sum())
data.dropna(inplace=True)

# checking unique values in different variables
unique_values = {}
for col in data.columns:
    unique_values[col] = data[col].value_counts().shape[0]

print(pd.DataFrame(unique_values, index=['unique value count']).transpose())

# check duplicated data
print(data.duplicated().sum())
# drop duplicated data
data.drop_duplicates(inplace=True)

data["Diabetes_str"] = data["Diabetes"].replace({0: "Not_Diabetic", 1: "Prediabetic", 2:"Diabetic"})

# Heatmap correlation------------------------------------------------------------------------
numeric_data = data.select_dtypes(include=['int', 'float'])
plt.figure(figsize=(20, 15))
sns.heatmap(numeric_data.corr(), annot=True, fmt=".2f")
plt.title("Features Correlation")
plt.show()

#histogram to understand dataset------------------------------------------------------------
data.hist(figsize=(20,15));

testdata=data.copy() 

testdata.Diabetes[testdata['Diabetes'] == 0] = 'No Diabetes'
testdata.Diabetes[testdata['Diabetes'] == 1] = 'Prediabetes'
testdata.Diabetes[testdata['Diabetes'] == 2] = 'Diabetes'


testdata.HighBP[testdata['HighBP'] == 0] = 'No High BP'
testdata.HighBP[testdata['HighBP'] == 1] = 'High BP'

testdata.HighChol[testdata['HighChol'] == 0] = 'No High Cholesterol'
testdata.HighChol[testdata['HighChol'] == 1] = 'High Cholesterol'

testdata.CholCheck[testdata['CholCheck'] == 0] = 'No Cholesterol Check in 5 Years'
testdata.CholCheck[testdata['CholCheck'] == 1] = 'Cholesterol Check in 5 Years'

testdata.Smoker[testdata['Smoker'] == 0] = 'No'
testdata.Smoker[testdata['Smoker'] == 1] = 'Yes'

testdata.Stroke[testdata['Stroke'] == 0] = 'No'
testdata.Stroke[testdata['Stroke'] == 1] = 'Yes'

testdata.HeartDiseaseorAttack[testdata['HeartDiseaseorAttack'] == 0] = 'No'
testdata.HeartDiseaseorAttack[testdata['HeartDiseaseorAttack'] == 1] = 'Yes'

testdata.PhysActivity[testdata['PhysActivity'] == 0] = 'No'
testdata.PhysActivity[testdata['PhysActivity'] == 1] = 'Yes'

testdata.Fruits[testdata['Fruits'] == 0] = 'No'
testdata.Fruits[testdata['Fruits'] == 1] = 'Yes'

testdata.Veggies[testdata['Veggies'] == 0] = 'No'
testdata.Veggies[testdata['Veggies'] == 1] = 'Yes'

testdata.HvyAlcoholConsump[testdata['HvyAlcoholConsump'] == 0] = 'No'
testdata.HvyAlcoholConsump[testdata['HvyAlcoholConsump'] == 1] = 'Yes'

testdata.AnyHealthcare[testdata['AnyHealthcare'] == 0] = 'No'
testdata.AnyHealthcare[testdata['AnyHealthcare'] == 1] = 'Yes'

testdata.NoDocbcCost[testdata['NoDocbcCost'] == 0] = 'No'
testdata.NoDocbcCost[testdata['NoDocbcCost'] == 1] = 'Yes'

testdata.GenHlth[testdata['GenHlth'] == 5] = 'Excellent'
testdata.GenHlth[testdata['GenHlth'] == 4] = 'Very Good'
testdata.GenHlth[testdata['GenHlth'] == 3] = 'Good'
testdata.GenHlth[testdata['GenHlth'] == 2] = 'Fair'
testdata.GenHlth[testdata['GenHlth'] == 1] = 'Poor'

testdata.DiffWalk[testdata['DiffWalk'] == 0] = 'No'
testdata.DiffWalk[testdata['DiffWalk'] == 1] = 'Yes'

testdata.Sex[testdata['Sex'] == 0] = 'Female'
testdata.Sex[testdata['Sex'] == 1] = 'Male'

testdata.Age[testdata['Age'] == 1] = '18 to 24'
testdata.Age[testdata['Age'] == 2] = '25 to 29'
testdata.Age[testdata['Age'] == 3] = '30 to 34'
testdata.Age[testdata['Age'] == 4] = '35 to 39'
testdata.Age[testdata['Age'] == 5] = '40 to 44'
testdata.Age[testdata['Age'] == 6] = '45 to 49'
testdata.Age[testdata['Age'] == 7] = '50 to 54'
testdata.Age[testdata['Age'] == 8] = '55 to 59'
testdata.Age[testdata['Age'] == 9] = '60 to 64'
testdata.Age[testdata['Age'] == 10] = '65 to 69'
testdata.Age[testdata['Age'] == 11] = '70 to 74'
testdata.Age[testdata['Age'] == 12] = '75 to 79'
testdata.Age[testdata['Age'] == 13] = '80 or older'

testdata.Education[testdata['Education'] == 1] = 'Never Attended School or kindergarten'
testdata.Education[testdata['Education'] == 2] = 'Grades 1 to 8'
testdata.Education[testdata['Education'] == 3] = 'Grades 9 to 12'
testdata.Education[testdata['Education'] == 4] = 'High School Graduate'
testdata.Education[testdata['Education'] == 5] = 'Some College or Technical School'
testdata.Education[testdata['Education'] == 6] = 'College Graduate'

testdata.Income[testdata['Income'] == 1] = 'Less Than $10,000'
testdata.Income[testdata['Income'] == 2] = 'Less Than $15,000'
testdata.Income[testdata['Income'] == 3] = 'Less Than $20,000'
testdata.Income[testdata['Income'] == 4] = 'Less Than $25,000'
testdata.Income[testdata['Income'] == 5] = 'Less Than $35,000'
testdata.Income[testdata['Income'] == 6] = 'Less Than $45,000'
testdata.Income[testdata['Income'] == 7] = 'Less Than $65,000'
testdata.Income[testdata['Income'] == 8] = '$75,000 or More'


# [Yes - NO] Columns and their relation with diabetes----------------------------------------
cols = ['HighBP', 'HighChol', 'CholCheck', 'Smoker', 'Stroke', 'HeartDiseaseorAttack',
        'PhysActivity', 'Fruits', 'Veggies', 'HvyAlcoholConsump', 'AnyHealthcare', 'NoDocbcCost',
        'DiffWalk']

def create_pivot(testdata, x_column):
    """Create a pivot table for satisfaction versus another rating for easy plotting."""
    df_plot = testdata.groupby([x_column, 'Diabetes_str']).size() \
        .reset_index().pivot(columns='Diabetes_str', index=x_column, values=0)
    return df_plot

# Set the color palette to "tab10"
sns.set_palette("tab10")
# Create subplots for [Yes - NO] Columns and their relation with diabetes
fig, axes = plt.subplots(5, 3, figsize=(20, 20))
axes = axes.ravel()
for i, col in enumerate(cols):
    create_pivot(testdata, col).plot(kind='bar', stacked=True, ax=axes[i])
    axes[i].set_xlabel(col)
    
# Adjust the space between subplots
plt.subplots_adjust(hspace=0.5, wspace=0.5)
# Set the title for the entire figure
fig.suptitle('[Yes - NO] Columns and their relation with Diabetes', fontsize=15)
plt.show()

# Pie chart for checking diabetic and non-diabetic people average----------------------------
fig, ax = plt.subplots(figsize=(8, 8))

# Create the pie chart using the entire dataset
labels = ["Not_Diabetic", "Diabetic", "Prediabetic"]
ax.pie(testdata["Diabetes_str"].value_counts(), labels=labels, autopct='%.02f')
ax.set_title('Distribution of Diabetes in the Dataset')
plt.show()

# Create a bar plot for Diabetes Disease Frequency for Ages----------------------------------
sns.set(style="whitegrid")
plt.figure(figsize=(12, 8))
# Define the order of age groups
age_order = [
    '18 to 24', '25 to 29', '30 to 34', '35 to 39', '40 to 44',
    '45 to 49', '50 to 54', '55 to 59', '60 to 64', '65 to 69',
    '70 to 74', '75 to 79', '80 or older'
]
# Use the order parameter to set the order of the x-axis (Age)
sns.countplot(x="Age", hue="Diabetes_str", data=testdata, palette="rocket", order=age_order)
# Set the title and labels
plt.title("Diabetes Disease Frequency for Ages", fontsize=18)
plt.xlabel("Age Group", fontsize=14)
plt.ylabel("Frequency", fontsize=14)
# Show the legend
plt.legend(title="Diabetes", loc="upper right", labels=["Not Diabetic", "Diabetic", "Prediabetic"])
# Rotate x-axis labels for better readability
plt.xticks(rotation=45)
plt.show()

#Relation between Sex and Diabetes--------------------------------------------------------
sns.countplot(x='Sex', hue='Diabetes_str', data=testdata)
sns.set_palette("Spectral")
plt.title('Relation between Gender and Diabetes')
plt.xlabel('Gender')
plt.ylabel('Count')
plt.show()

#BMI Distribution by Diabetes Status------------------------------------------------------
# Map numerical values to labels in the "Diabetes_str" column
data['Diabetes_str'] = data['Diabetes'].map({0: 'No Diabetes', 1: 'Prediabetes', 2: 'Diabetes'})

# Create a bar plot for "BMI" and its relation with "Diabetes"
plt.figure(figsize=(25, 15))
sns.countplot(data=data, x='BMI', hue='Diabetes_str', palette={"No Diabetes": "red", "Prediabetes": "green", "Diabetes": "blue"})
plt.title("Relation between BMI and Diabetes status")
plt.legend(title='Diabetes Status')
plt.show()

# Create a hist plot for Relation between Education and Diabetes-----------------------------
education_order = [
    'Never Attended School or kindergarten',
    'Grades 1 to 8',
    'Grades 9 to 12',
    'High School Graduate',
    'Some College or Technical School',
    'College Graduate'
]

testdata['Education'] = pd.Categorical(testdata['Education'], categories=education_order, ordered=True)

# Plot the distribution
plt.figure(figsize=(16, 8))
ax = sns.histplot(data=testdata[testdata["Diabetes_str"] == 'Not_Diabetic'], x='Education', color="tomato", label="Not_Diabetic", binwidth=0.5, stat="count")
sns.histplot(data=testdata[testdata["Diabetes_str"] == 'Prediabetic'], x='Education', color="gold", label="Prediabetic", binwidth=0.5, stat="count", ax=ax)
sns.histplot(data=testdata[testdata["Diabetes_str"] == 'Diabetic'], x='Education', color="mediumseagreen", label="Diabetic", binwidth=0.5, stat="count", ax=ax)

ax.set_title("Relation between Education and Diabetes")
ax.set_xlabel("Education Level")
ax.set_ylabel("Count")

# Set x-axis tick positions and labels
tick_positions = range(len(education_order))
ax.set_xticks(tick_positions)
ax.set_xticklabels(education_order, rotation=45)

# Create a twin Axes sharing the xaxis
ax2 = ax.twinx()

# Plot the KDE on the second y-axis with labels
sns.histplot(data=testdata[testdata["Diabetes_str"] == 'Not_Diabetic'], x='Education', color="tomato", label="Not_Diabetic", binwidth=0.5, stat="density", kde=True, ax=ax2)
sns.histplot(data=testdata[testdata["Diabetes_str"] == 'Prediabetic'], x='Education', color="gold", label="Prediabetic", binwidth=0.5, stat="density", kde=True, ax=ax2)
sns.histplot(data=testdata[testdata["Diabetes_str"] == 'Diabetic'], x='Education', color="mediumseagreen", label="Diabetic", binwidth=0.5, stat="density", kde=True, ax=ax2)

ax2.set_ylabel("Density")

# Show the legend
handles, labels = ax.get_legend_handles_labels()
handles2, labels2 = ax2.get_legend_handles_labels()
ax.legend(handles=handles + handles2, labels=labels + labels2, title="Diabetes", loc="upper right")

# Show the plot
plt.tight_layout()
plt.show()

# Define the order of "Income" categories----------------------------------------------------
income_order = [
    'Less Than $10,000',
    'Less Than $15,000',
    'Less Than $20,000',
    'Less Than $25,000',
    'Less Than $35,000',
    'Less Than $45,000',
    'Less Than $65,000',
    '$75,000 or More'
]
# Convert 'Income' to categorical with the specified order
testdata['Income'] = pd.Categorical(testdata['Income'], categories=income_order, ordered=True)

# Set the style of seaborn
sns.set(style="whitegrid")

# Create a distribution plot for "Income" and its relation with "Diabetes"
plt.figure(figsize=(14, 8))
sns.histplot(data=testdata, x="Income", hue="Diabetes_str", multiple="stack", palette="viridis", kde=True)
plt.title('Distribution of Income and its relation with Diabetes')
plt.xlabel('Income')
plt.ylabel('Count')
plt.show()


# Dist plot for "GenHlth" and its relation with the target
plt.figure(figsize=(12, 8))
sns.histplot(data=testdata, x="GenHlth", hue="Diabetes_str", multiple="stack", bins=5, palette="rocket")
plt.title('Distribution of General Health and its Relation with Diabetes')
plt.xlabel('General Health Rating (1 = Excellent, 5 = Poor)')
plt.ylabel('Count')
plt.show()


# Assuming your target variable is named "Diabetes_str"
sns.set(style="whitegrid")
plt.figure(figsize=(12, 6))
# Distribution plot for "MentHlth"
sns.distplot(testdata[testdata['Diabetes_str'] == 'Not_Diabetic']['MentHlth'], label='Not Diabetic', hist=False, kde_kws={'shade': True})
sns.distplot(testdata[testdata['Diabetes_str'] == 'Diabetic']['MentHlth'], label='Diabetic', hist=False, kde_kws={'shade': True})
sns.distplot(testdata[testdata['Diabetes_str'] == 'Prediabetic']['MentHlth'], label='Prediabetic', hist=False, kde_kws={'shade': True})
plt.title('Distribution of "MentHlth" and its Relation with Diabetes')
plt.xlabel('Days of Poor Mental Health (MentHlth)')
plt.legend()
plt.show()

sns.set(style="whitegrid")
plt.figure(figsize=(12, 8))
# Dist plot for PhysHlth based on the target variable
ax = sns.histplot(data=testdata, x='PhysHlth', hue='Diabetes_str', multiple="stack", bins=30, kde=True)
plt.title('Distribution of PhysHlth and its Relation with Diabetes')
plt.xlabel('PhysHlth (Physical illness or injury days in the past 30 days)')
plt.ylabel('Count')
# Manually create legend with specified colors
legend_labels = ['Not_Diabetic', 'Diabetic', 'Prediabetic']
legend_colors = sns.color_palette()[:len(legend_labels)]
legend_handles = [plt.Line2D([0], [0], color=legend_colors[i], label=legend_labels[i]) for i in range(len(legend_labels))]
plt.legend(handles=legend_handles, title='Diabetes', loc='upper right')
plt.show()

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split, RandomizedSearchCV
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from xgboost import XGBClassifier
from sklearn.metrics import mean_squared_error, classification_report, confusion_matrix, roc_curve, auc
import math
import matplotlib.pyplot as plt
from sklearn.metrics import ConfusionMatrixDisplay

# Load the data
data = pd.read_csv("C:/Users/chngk/OneDrive/Desktop/Machine_learning/heart_disease_health_indicators_BRFSS2015.csv", sep=",", encoding='utf-8')

# Assuming 'HighBP' is a categorical variable, replace it with the actual name of the categorical variable
categorical_columns = ['HighBP', 'HighChol', 'CholCheck', 'BMI', 'Smoker', 'Stroke', 'HeartDiseaseorAttack', 'PhysActivity', 'Fruits', 'Veggies', 'HvyAlcoholConsump', 'AnyHealthcare', 'NoDocbcCost', 'GenHlth', 'MentHlth', 'PhysHlth', 'DiffWalk', 'Sex', 'Age', 'Education', 'Income']

# Combine prediabetic and diabetic to diabetic
data['Diabetes'] = data['Diabetes'].replace({0: 0, 1: 1, 2: 1})

# One-hot encode categorical variables
X_encoded = pd.get_dummies(data[categorical_columns], columns=categorical_columns)

# Split the data into training and testing sets
X_train, X_test, Y_train, Y_test = train_test_split(X_encoded, data['Diabetes'], test_size=0.2, random_state=42)

# Initialize Logistic Regression model
lg = LogisticRegression(max_iter=1500, solver='lbfgs')

# Hyperparameter tuning using random search
param_distributions = {'C': [0.001, 0.01, 0.1, 1, 10, 100, 1000], 'penalty': ['l2']}
random_search = RandomizedSearchCV(lg, param_distributions, n_iter=5, scoring='accuracy', cv=5, random_state=42, n_jobs=-1)
random_search.fit(X_train, Y_train)

# Get the best hyperparameters
best_params = random_search.best_params_
print("Best Hyperparameters:", best_params)

# Initialize and fit the logistic regression model with the best hyperparameters
lg = LogisticRegression(max_iter=1500, C=best_params['C'], penalty=best_params['penalty'], solver='lbfgs')
lg.fit(X_train, Y_train)

# Make predictions on the test set
y_pred_lg = lg.predict(X_test)

# Print training and test set scores
print('Logistic Regression:')
print('Training set score: {:.4f}'.format(lg.score(X_train, Y_train)))
print('Test set score: {:.4f}'.format(lg.score(X_test, Y_test)))

# Check MSE & RMSE
mse_lg = mean_squared_error(Y_test, y_pred_lg)
print('Mean Squared Error: {:.4f}'.format(mse_lg))
rmse_lg = math.sqrt(mse_lg)
print('Root Mean Squared Error: {:.4f}'.format(rmse_lg))

# Display classification report
matrix_lg = classification_report(Y_test, y_pred_lg)
print(matrix_lg)

# Calculate and plot the confusion matrix
cm_lg = confusion_matrix(Y_test, y_pred_lg)
disp_lg = ConfusionMatrixDisplay(confusion_matrix=cm_lg, display_labels=['No Diabetes', 'Diabetes'])
disp_lg.plot(cmap='Blues', values_format='.2f', colorbar=True)
plt.show()

# Calculate ROC curve and AUC for Logistic Regression
y_pred_proba_lg = lg.predict_proba(X_test)[:, 1]
fpr_lg, tpr_lg, thresholds_lg = roc_curve(Y_test, y_pred_proba_lg)
roc_auc_lg = auc(fpr_lg, tpr_lg)

# Plot ROC curve for Logistic Regression
plt.figure(figsize=(8, 8))
plt.plot(fpr_lg, tpr_lg, color='darkorange', lw=2, label='ROC curve (AUC = {:.2f})'.format(roc_auc_lg))
plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('Logistic Regression - Receiver Operating Characteristic (ROC) Curve')
plt.legend(loc='lower right')
plt.show()

# Calculate precision, recall, and accuracy
TN_lg, FP_lg, FN_lg, TP_lg = cm_lg.ravel()
precision_lg = TP_lg / (TP_lg + FP_lg)
recall_lg = TP_lg / (TP_lg + FN_lg)
accuracy_lg = (TP_lg + TN_lg) / (TP_lg + TN_lg + FP_lg + FN_lg)

# Print precision, recall, and accuracy
print('Precision: {:.4f}'.format(precision_lg))
print('Recall: {:.4f}'.format(recall_lg))
print('Accuracy: {:.4f}'.format(accuracy_lg))

# Initialize Random Forest model
rf = RandomForestClassifier(random_state=42)

# Hyperparameter tuning using random search
param_distributions_rf = {
    'n_estimators': [50, 100],
    'max_depth': [None, 10, 20],
    'min_samples_split': [2, 5],
    'min_samples_leaf': [1, 2]
}
random_search_rf = RandomizedSearchCV(rf, param_distributions_rf, n_iter=5, scoring='accuracy', cv=5, random_state=42)
random_search_rf.fit(X_train, Y_train)

# Get the best hyperparameters
best_params_rf = random_search_rf.best_params_
print("Best Hyperparameters (Random Forest):", best_params_rf)

# Initialize and fit the Random Forest model with the best hyperparameters
rf = RandomForestClassifier(
    n_estimators=best_params_rf['n_estimators'],
    max_depth=best_params_rf['max_depth'],
    min_samples_split=best_params_rf['min_samples_split'],
    min_samples_leaf=best_params_rf['min_samples_leaf'],
    random_state=42
)
rf.fit(X_train, Y_train)

# Make predictions on the test set
y_pred_rf = rf.predict(X_test)

# Print training and test set scores
print('Random Forest:')
print('Training set score: {:.4f}'.format(rf.score(X_train, Y_train)))
print('Test set score: {:.4f}'.format(rf.score(X_test, Y_test)))

# Calculate Mean Squared Error (MSE)
mse_rf = mean_squared_error(Y_test, y_pred_rf)
print('Mean Squared Error: {:.4f}'.format(mse_rf))
# Calculate Root Mean Squared Error (RMSE)
rmse_rf = np.sqrt(mse_rf)
print('Root Mean Squared Error: {:.4f}'.format(rmse_rf))

# Display classification report
matrix_rf = classification_report(Y_test, y_pred_rf)
print(matrix_rf)

# Calculate and plot the confusion matrix
cm_rf = confusion_matrix(Y_test, y_pred_rf)
disp_rf = ConfusionMatrixDisplay(confusion_matrix=cm_rf, display_labels=['No Diabetes', 'Diabetes'])
disp_rf.plot(cmap='Purples', values_format='.2f', colorbar=True)
plt.show()

# Calculate precision, recall, and accuracy for Random Forest
TN_rf, FP_rf, FN_rf, TP_rf = cm_rf.ravel()
precision_rf = TP_rf / (TP_rf + FP_rf)
recall_rf = TP_rf / (TP_rf + FN_rf)
accuracy_rf = (TP_rf + TN_rf) / (TP_rf + TN_rf + FP_rf + FN_rf)

# Print precision, recall, and accuracy
print('Precision: {:.4f}'.format(precision_rf))
print('Recall: {:.4f}'.format(recall_rf))
print('Accuracy: {:.4f}'.format(accuracy_rf))

# Calculate ROC curve and AUC for Random Forest
y_pred_proba_rf = rf.predict_proba(X_test)[:, 1]
fpr_rf, tpr_rf, thresholds_rf = roc_curve(Y_test, y_pred_proba_rf)
roc_auc_rf = auc(fpr_rf, tpr_rf)

# Plot ROC curve for Random Forest
plt.figure(figsize=(8, 8))
plt.plot(fpr_rf, tpr_rf, color='darkorange', lw=2, label='ROC curve (AUC = {:.2f})'.format(roc_auc_rf))
plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('Random Forest - Receiver Operating Characteristic (ROC) Curve')
plt.legend(loc='lower right')
plt.show()

# Initialize XGBoost model
xgb = XGBClassifier(random_state=42)

# Hyperparameter tuning using random search
param_dist_xgb = {
    'n_estimators': [50, 100, 150],
    'max_depth': [3, 5, 7],
    'learning_rate': [0.01, 0.1, 0.2]
}
random_search_xgb = RandomizedSearchCV(estimator=xgb, param_distributions=param_dist_xgb, n_iter=10, scoring='accuracy', cv=5, random_state=42)
random_search_xgb.fit(X_train, Y_train)

# Get the best hyperparameters
best_params_xgb = random_search_xgb.best_params_
print("Best Hyperparameters (XGBoost):", best_params_xgb)

# Use the best parameters to initialize the final model
xgb_best = XGBClassifier(random_state=42, **best_params_xgb)
xgb_best.fit(X_train, Y_train)

# Make predictions on the test set
y_pred_xgb = xgb_best.predict(X_test)

# Convert categorical labels to binary (0 and 1) for XGBoost
Y_test_binary_xgb = Y_test.replace({'No Diabetes': 0, 'Diabetes': 1})

# Print training and test set scores
print('XGBoost:')
print('Training set score: {:.4f}'.format(xgb_best.score(X_train, Y_train)))
print('Test set score: {:.4f}'.format(xgb_best.score(X_test, Y_test)))

# Calculate Mean Squared Error (MSE)
mse_xgb = mean_squared_error(Y_test, y_pred_xgb)
print('Mean Squared Error: {:.4f}'.format(mse_xgb))
# Calculate Root Mean Squared Error (RMSE)
rmse_xgb = np.sqrt(mse_xgb)
print('Root Mean Squared Error: {:.4f}'.format(rmse_xgb))

# Display classification report
matrix_xgb = classification_report(Y_test, y_pred_xgb)
print(matrix_xgb)

# Calculate and plot the confusion matrix
cm_xgb = confusion_matrix(Y_test, y_pred_xgb)
disp_xgb = ConfusionMatrixDisplay(confusion_matrix=cm_xgb, display_labels=['No Diabetes', 'Diabetes'])
disp_xgb.plot(cmap='Reds', values_format='.2f', colorbar=True)
plt.show()

# Calculate precision, recall, and accuracy for XGBoost
TN_xgb, FP_xgb, FN_xgb, TP_xgb = cm_xgb.ravel()
precision_xgb = TP_xgb / (TP_xgb + FP_xgb)
recall_xgb = TP_xgb / (TP_xgb + FN_xgb)
accuracy_xgb = (TP_xgb + TN_xgb) / (TP_xgb + TN_xgb + FP_xgb + FN_xgb)

# Print precision, recall, and accuracy
print('Precision: {:.4f}'.format(precision_xgb))
print('Recall: {:.4f}'.format(recall_xgb))
print('Accuracy: {:.4f}'.format(accuracy_xgb))

# Calculate ROC curve and AUC for XGBoost
y_pred_proba_xgb = xgb_best.predict_proba(X_test)[:, 1]
fpr_xgb, tpr_xgb, thresholds_xgb = roc_curve(Y_test_binary_xgb, y_pred_proba_xgb)
roc_auc_xgb = auc(fpr_xgb, tpr_xgb)

# Plot ROC curve for XGBoost
plt.figure(figsize=(8, 8))
plt.plot(fpr_xgb, tpr_xgb, color='darkorange', lw=2, label='ROC curve (AUC = {:.2f})'.format(roc_auc_xgb))
plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('XGBoost - Receiver Operating Characteristic (ROC) Curve')
plt.legend(loc='lower right')
plt.show()

# Import necessary libraries
import matplotlib.pyplot as plt
import numpy as np
from sklearn.model_selection import train_test_split, RandomizedSearchCV
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from xgboost import XGBClassifier
from sklearn.metrics import classification_report, confusion_matrix, roc_curve, auc, mean_squared_error
from sklearn.metrics import ConfusionMatrixDisplay
from tabulate import tabulate  # Import tabulate

def evaluate_model(model, X_train, Y_train, X_test, Y_test, model_name):
    # Fit the model
    model.fit(X_train, Y_train)

    # Make predictions on the test set
    y_pred = model.predict(X_test)

    # Calculate training and test set scores
    train_score = model.score(X_train, Y_train)
    test_score = model.score(X_test, Y_test)

    # Calculate Mean Squared Error (MSE)
    mse = mean_squared_error(Y_test, y_pred)
    # Calculate Root Mean Squared Error (RMSE)
    rmse = np.sqrt(mse)

    # If the model supports probability predictions, calculate ROC curve and AUC
    if hasattr(model, 'predict_proba'):
        y_pred_proba = model.predict_proba(X_test)[:, 1]
        fpr, tpr, thresholds = roc_curve(Y_test, y_pred_proba)
        roc_auc = auc(fpr, tpr)

        # Return all metrics
        return {
            'Training Accuracy': train_score,
            'Test Accuracy': test_score,
            'MSE': mse,
            'RMSE': rmse,
            'ROC AUC': roc_auc
        }
    else:
        # Return metrics without ROC AUC
        return {
            'Training Accuracy': train_score,
            'Test Accuracy': test_score,
            'MSE': mse,
            'RMSE': rmse
        }

# Initialize models
logistic_regression = LogisticRegression(max_iter=1500, C=10, penalty='l2', solver='lbfgs')
random_forest = RandomForestClassifier(n_estimators=100, max_depth=None, min_samples_split=2, min_samples_leaf=1, random_state=42)
xgboost = XGBClassifier(n_estimators=150, max_depth=3, learning_rate=0.01, random_state=42)

# Evaluate each model and collect metrics
logreg_metrics = evaluate_model(logistic_regression, X_train, Y_train, X_test, Y_test, 'Logistic Regression')
rf_metrics = evaluate_model(random_forest, X_train, Y_train, X_test, Y_test, 'Random Forest')
xgb_metrics = evaluate_model(xgboost, X_train, Y_train, X_test, Y_test, 'XGBoost')

# Combine metrics into lists
metrics_names = list(logreg_metrics.keys())
logreg_values = [logreg_metrics[name] for name in metrics_names]
rf_values = [rf_metrics[name] for name in metrics_names]
xgb_values = [xgb_metrics[name] for name in metrics_names]

# Combine values into a list of tuples
table_data = list(zip(metrics_names, logreg_values, rf_values, xgb_values))

# Print metrics in tabular form
print(tabulate(table_data, headers=['Metric', 'Logistic Regression', 'Random Forest', 'XGBoost'], tablefmt="pretty"))

# Plot comparison of Model Accuracy with different colors
fig, axes = plt.subplots(nrows=1, ncols=2, figsize=(15, 6))

# Bar plot for Accuracy
bar_width = 0.35
model_names = ['Logistic Regression', 'Random Forest', 'XGBoost']
x_ticks = np.arange(len(model_names))

# Overall Accuracy bars
axes[0].bar(x_ticks, [logreg_values[1], rf_values[1], xgb_values[1]], width=bar_width, alpha=0.7, label='Accuracy', color='blue')

axes[0].set_xticks(x_ticks)
axes[0].set_xticklabels(model_names)
axes[0].set_ylabel('Accuracy')
axes[0].set_title('Comparison of Model Accuracy')
axes[0].legend()

# Bar plot for RMSE
axes[1].bar(model_names, [logreg_values[3], rf_values[3], xgb_values[3]], alpha=0.7, label='RMSE', color='green')
axes[1].set_ylabel('RMSE')
axes[1].set_title('Comparison of RMSE across Models')
axes[1].legend()

plt.show()