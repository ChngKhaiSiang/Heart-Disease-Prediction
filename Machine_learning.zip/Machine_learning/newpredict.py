import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
import streamlit as st

# Load your dataset
# Replace 'C:/Users/chngk/OneDrive/Desktop/Machine_learning/diabetes.csv' with the actual file path
data = pd.read_csv("C:/Users/chngk/OneDrive/Desktop/Machine_learning/diabetes.csv")

# Preprocessing
# Handle missing values
imputer = SimpleImputer(strategy='mean')
data[['Glucose', 'BloodPressure', 'SkinThickness', 'Insulin', 'BMI']] = imputer.fit_transform(data[['Glucose', 'BloodPressure', 'SkinThickness', 'Insulin', 'BMI']])

# Feature scaling
scaler = StandardScaler()
data[['Glucose', 'BloodPressure', 'SkinThickness', 'Insulin', 'BMI', 'DiabetesPedigreeFunction', 'Age']] = scaler.fit_transform(data[['Glucose', 'BloodPressure', 'SkinThickness', 'Insulin', 'BMI', 'DiabetesPedigreeFunction', 'Age']])

# Feature selection
features = ['Pregnancies', 'Glucose', 'BloodPressure', 'SkinThickness', 'Insulin', 'BMI', 'DiabetesPedigreeFunction', 'Age']
X = data[features].copy()
y = data['Outcome']  # Assuming 'Outcome' is the target variable

# Split the data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Preprocess categorical features using OneHotEncoder
numeric_features = ['Pregnancies', 'Glucose', 'BloodPressure', 'SkinThickness', 'Insulin', 'BMI', 'DiabetesPedigreeFunction', 'Age']

preprocessor = ColumnTransformer(
    transformers=[
        ('num', 'passthrough', numeric_features),
        # Add ('cat', YourCategoricalEncoder(), categorical_features) if needed
    ])

# Create a pipeline with preprocessing and RandomForest model
model = Pipeline(steps=[('preprocessor', preprocessor),
                         ('classifier', RandomForestClassifier())])

# Train the model
model.fit(X_train, y_train)

# Streamlit web app
st.title("Diabetes Prediction")

# User input for features
with st.form(key='my_form'):
    pregnancies = st.number_input("Number of times pregnant", min_value=0)
    glucose = st.number_input("Plasma glucose concentration (mg/dL)", min_value=0)
    blood_pressure = st.number_input("Diastolic blood pressure (mm Hg)", min_value=0)
    skin_thickness = st.number_input("Triceps skin fold thickness (mm)", min_value=0)
    insulin = st.number_input("2-Hour serum insulin (mu U/ml)", min_value=0)
    bmi = st.number_input("Body mass index (BMI)", min_value=0)
    diabetes_pedigree_function = st.number_input("Diabetes pedigree function", min_value=0)
    age = st.number_input("Age (years)", min_value=0)

    submitted = st.form_submit_button("Submit")

# Create a button for submission
if submitted:
    # Create a DataFrame from user input
    user_data = pd.DataFrame({
        'Pregnancies': [pregnancies],
        'Glucose': [glucose],
        'BloodPressure': [blood_pressure],
        'SkinThickness': [skin_thickness],
        'Insulin': [insulin],
        'BMI': [bmi],
        'DiabetesPedigreeFunction': [diabetes_pedigree_function],
        'Age': [age]
    })

    # Make prediction
    prediction = model.predict(user_data)

    # Display the prediction result
    if prediction[0] == 1:
        st.success("The model predicts that the person has diabetes.")
    else:
        st.success("The model predicts that the person does not have diabetes.")
